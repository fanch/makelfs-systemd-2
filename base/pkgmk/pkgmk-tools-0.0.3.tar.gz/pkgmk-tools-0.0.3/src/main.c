#include <stdio.h>
#include <string.h>
#include <pkg-get.h>
int main(int argc, char** argv)
{
	int i=0;
	if (argc<2) return 0; 
	mirList *listOfMirrors=NULL;
	pkgList *listOfPackages=NULL;
	pkgInfo *pkg=NULL;
	listOfMirrors = getAvailableMirrors("");
	listOfPackages = getAvailablePackages(listOfMirrors);
	pkg=getFirstPackageFromList(listOfPackages,argv[1]);
	if (pkg !=NULL)
	{
		for (i=0;i<listOfPackages->count;i++)
		{
			if (!strcmp(pkg->name,listOfPackages->pkgs[i]->name))
			{
				if (!strcmp(basename(argv[0]),"pkg-get-md5sum"))
					printf("%s %s\n",listOfPackages->pkgs[i]->md5sum,getDirPackage(listOfMirrors,listOfPackages->pkgs[i]));
				if (!strcmp(basename(argv[0]),"pkg-get-version"))
					printf("%s\n",listOfPackages->pkgs[i]->version);
				if (!strcmp(basename(argv[0]),"pkg-get-url"))
					printf("%s\n",getUrlPackage(listOfMirrors,listOfPackages->pkgs[i]));
				break;
			}
		}
	}
	if (listOfMirrors!=NULL)
		freeMirrorList(listOfMirrors);
	if (listOfPackages !=NULL) 
		freePkgList(listOfPackages);
	if (pkg !=NULL)
		freePkgInfo(pkg);
	return 0;
}
