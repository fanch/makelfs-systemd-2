#!/usr/bin/env perl
#
# pkg-repgen: generates a binary repository for pkg-get
#
# requires prt-get
#
# html index generation code adapted from Jukka Heino's portspage
#
# usage: pkg-repgen [<pkgname1>..<pkgnameN>]
#

use warnings;
use strict;
use Getopt::Long;

our $title = "Paquets NuTyX Architecture i686"; our $header; our $footer;
GetOptions("title=s"=>\$title, "header=s"=>\$header, "footer=s"=>\$footer);

if ($#ARGV >= 0) { # single packages
    pkgrepo_single();
    pkgdeps_single();
    pkgread();
    pkginst();
} else {
    pkgrepo();
    pkgdeps();
    pkgread();
    pkginst();
    pkgfiles();
	 pkgbuilds();
}

######################## single packages ########################

# generate dependencies
sub pkgdeps_single {
    print "+ Génère les dépendances\n";
    my $hasnew = 0;
    foreach my $p (@ARGV) {
        my @packages = glob("$p#*.pkg.tar.xz");
        if ($#packages == 0) {
            my $found = 0;
            my $package = $packages[0];
            $package =~ s/#.*//;
            my $deps = `prt-get printf "%e" --filter="$package"`;
            if ($deps ne "") {
                my $isnew = `grep "$p .*:" PKGDEPS`;
                if ($isnew eq ""){ # package is new, put deps at the end.
                    open (my $fh, '>>PKGDEPS');
                    printf $fh "%-30s : %-s\n", $package, $deps;
                    close $fh;
                    $hasnew = 1;
                } else {
                    system("sed -i \"/^$p /s/: .*\$/: $deps/\" PKGDEPS");
                }
            }
            
        } else {
            print "Paquet '$p' pas trouvé ou double\n"
        }
	}
    if ($hasnew == 1){system("sort -o PKGDEPS PKGDEPS")};
}

# generate the main repository file
sub pkgrepo_single {
    print "+ Génère le dépot\n";
    my $hasnew = 0;
    foreach my $p (@ARGV) {
        my @packages = glob("$p#*.pkg.tar.xz");
        if ($#packages == 0) {
            my $found = 0;
            my $package = $packages[0];
            my $name = $package;
            $name =~ s/#.*//;
            my $du = (-s $package);
            my $md5 = `md5sum $package`;
            $md5 =~ s/  .*$|\n//g;
            my $des=`prt-get printf %d --filter="$name"`;
            $des =~ s/:/ /g;
            if ($des eq ""){$des = "N.A."};
            my $flags=`prt-get printf %E:%O:%R --filter="$name"`;
            if ($flags eq "") {$flags = "no:no:no"}
            my $isnew = `grep "$p#" PKGREPO`;
            if ($isnew eq ""){ # package is new, put it at the end
                open (my $fh, '>>PKGREPO');
                printf $fh "%-s:%-s:%-s:%-s:%-s\n", $package,$du,$md5,$des,$flags;
                close $fh;
                $hasnew = 1;
            } else {
                my $newp = "$package:$du:$md5:$des:$flags";
                system("sed -i \"s/^$p#.*\$/$newp/\" PKGREPO");
            }
            #printf $fh "%-s:%-s:%-s:%-s\n", $du,$md5,$des,$flags;
        } else {
            print "Paquet '$p' pas trouvé ou double\n"
        }
    }
    if ($hasnew == 1){system("sort -o PKGREPO PKGREPO")};
}


######################## full repository ########################

# generate dependencies
sub pkgdeps {
    print "+ Génère les dépendances\n";
    system ("deps.awk list run");
}
# generate the main repository file and index page
sub pkgrepo {
    print "+ Génère le dépot\n";
    my @packages = glob("*#*.pkg.tar.xz");
	our $odd = "odd";
	my $count = 0;
    open (my $fh, '>PKGREPO');
	printheader();
	open (my $ih, '>>index.html');
	foreach my $package (@packages) {
		my $date = (stat($package))[9];
		$count++;
        $package =~ s/\n//g;
        my $name = $package;
        $name =~ s/#.*//;
        my $du = (-s $package);
        my $md5 = `md5sum $package`;
        $md5 =~ s/  .*$|\n//g;
        my $des=`prt-get printf %d --filter="$name"`;
        $des =~ s/:/ /g;
		  my $URL=`prt-get printf %u --filter="$name"`;
		  $URL =~ s/:/ /g;
		  my $maintainer=`prt-get printf %M --filter="$name"`;
		  $maintainer =~ s/:/ /g;
		  my $packagaer=`prt-get printf %P --filter="$name"`;
		  $packagaer =~ s/:/ /g;
        if ($des eq ""){$des = "N.A."};
        my $flags=`prt-get printf %E:%O:%R --filter="$name"`;
        if ($flags eq "") {$flags = "no:no:no"}
        printf $fh "%-s:%-s:%-s:%-s:%-s:%-s:%-s:%-s\n", $package,$du,$md5,$des,$flags,$URL,$maintainer,$packagaer;
		my $version = $package;
		$version =~ s/^.*\#//;
		$version =~ s/\.pkg\.tar\.xz//;
		print $ih "   <tr class=\"$odd\">";
		print $ih "<td>$name</td>";
		my $url = $package;
		$url =~ s/\#/\%23/;
		print $ih "<td><a href=\"$url\">$version</a></td>";
		print $ih "<td>$des</td>";
		print $ih "<td>" . isotime($date, 1) . "</td>";
		print $ih "</tr>\n";

		if ($odd eq "odd") { $odd = "even"; }
		else { $odd = "odd"; }
    }
    close $fh;
    close $ih;
	printfooter($count);
}
# generate PKGBUILDS file
sub pkgbuilds {
    print "+ Génère les recettes\n";
    my @packages = glob("*#*.pkg.tar.xz");
    open (my $fh, '>PKGBUILDS');
    print $fh "# PKGBUILDS files for Pkgfiles. Do NOT remove this line.\n";
        foreach my $package(@packages){
        $package =~ s/#.*//;
        my $path = `prt-get path $package`;
        $path =~ s/\n//g;
        if (-f "$path/Pkgfile") {
                print $fh "##### PKGBUILD: $package\n";
                open(my $pkgfile, "$path/Pkgfile");
                 while (<$pkgfile>){
                        my $line = $_;
                        print $fh $line;
                        }
                close($pkgfile);
                }
        }
        print $fh "##### end PKGBUILDS\n";
        close($fh);
        system("gzip -c PKGBUILDS > PKGBUILDS.gz");
}
# generate PKGFILES file
sub pkgfiles {
    print "+ Génère footprint\n";
    my @packages = glob("*#*.pkg.tar.xz");
    open (my $fh, '>PKGFILES');
    print $fh "# PKGFILES files for repository. Do NOT remove this line.\n";
        foreach my $package(@packages){
        $package =~ s/#.*//;
        my $path = `prt-get path $package`;
        $path =~ s/\n//g;
        if (-f "$path/.footprint.i686"){
                print $fh "##### PKGFILES: $package\n";
                open(my $footprint, "$path/.footprint.i686");
                while (<$footprint>){
                        my $line = $_;
                        print $fh $line;
                        }
                close($footprint);
                }
        }
		  print $fh "##### end PKGFILES\n";
        close($fh);
	system("gzip -c PKGFILES > PKGFILES.gz");
}
# generate README file
sub pkgread {
    print "+ Génère README\n";
    my @packages = glob("*#*.pkg.tar.xz");
    open (my $fh, '>PKGREAD');
    print $fh "# README files for repository. Do NOT remove this line.\n";
	foreach my $package (@packages) {
        $package =~ s/#.*//;
        my $path = `prt-get path $package`;
        $path =~ s/\n//g;
        if (-f "$path/README"){
            print $fh "##### PKGREADME: $package\n";
            open(my $readme, "$path/README");
            while (<$readme>){
	            my $line = $_;
                print $fh $line;
            }
            close($readme);
        }
    }
    close $fh;
}

# generate pre-post install scripts file
sub pkginst {
    print "+ Génère les scripts\n";
    open (my $fh, '>PKGINST');
    print $fh 
"
#!/bin/bash
#
# PKGINST: pre-post install scripts
";
    my @packages = glob("*#*.pkg.tar.xz");
	foreach my $package (@packages) {
        $package =~ s/#.*//;
        my $path = `prt-get path $package`;
        $path =~ s/\n//g;
        my $normal= $package;
        $normal =~ s/[^[:alnum:]]/-/g;
        if (-f "$path/pre-install"){
            print $fh "${normal}_pre_install() {\n";
            open(my $pre, "$path/pre-install");
            while (<$pre>){
	            my $line = $_;
                print $fh $line;
            }
            close($pre);
            print $fh "}\n\n";
        }
        if (-f "$path/post-install"){
            print $fh "${normal}_post_install() {\n";
            open(my $post, "$path/post-install");
            while (<$post>){
	            my $line = $_;
                print $fh $line;
            }
            close($post);
            print $fh "}\n\n";
        }
    }
    print $fh "\n\n";
    print $fh 'if [ ! -z "$1" ]; then $1; fi';
    print $fh "\n";
    close $fh;
}


######################## html index subs ########################

sub printheader {
    open (my $ih, '>index.html');
	print $ih <<EOH;
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN"
    "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
 <head>
EOH

	print $ih "  <title>$title</title>\n";

	print $ih <<EOH;
  <style type="text/css">
   body
   {
    font-family: Verdana, sans-serif;
    font-size: 85%;
    padding: 2em;
   }
   a
   {
    color: #67550d;
   }
   table
   {
    border: solid #e5dccf 1px;
    font-size: 85%;
   }
   td
   {
    padding: 6px;
   }
   tr.header
   {
    background-color: #e5dccf;
   }
   tr.odd
   {
    background-color: #f7f3ed;
   }
   tr.even
   {
    background-color: #fcf9f8;
   }
  </style>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
 </head>
 <body>
EOH

	print $ih "  <h2>$title</h2>\n";
	if ($header) {
		open(FILE, $header) or die "Couldn't open header file";
		while (<FILE>) {
			print $ih "  " . $_;
		}
		close(FILE);
	}

	print $ih "  <table width=\"100%\" cellspacing=\"0\">\n";
	print $ih "   <tr class=\"header\"><td><b>Nom</b></td><td><b>Version</b></td><td><b>Description</b></td>";
	print $ih "<td><b>Dernière compilation</b></td>";
	print $ih "</tr>\n";
	close($ih);
}

sub printfooter {
	my $count = $_[0];
    open (my $ih, '>>index.html');
	print $ih "  </table>\n";
	print $ih "  <p><b>$count paquets</b></p>\n";
	if ($footer) {
		open(FILE, $footer) or die "Fichier de pied de page pas trouvé";
		while (<FILE>) {
			print $ih "  " . $_;
		}
		close(FILE);
	}
	print $ih "  <p><i>Généré par <a href=\"http://www.varlock.com\">pkg-repgen</a> le " . isotime() . ".</i></p>\n";
	print $ih <<EOH;
 </body>
</html>
EOH
	close($ih);

}

sub isotime {
	my $time = (shift or time);
	my $accuracy = (shift or 2);
	my @t = gmtime ($time);
	my $year = $t[5] + 1900;
	my $month = sprintf("%02d", $t[4] + 1);
	my $day = sprintf("%02d", $t[3]);

	if ($accuracy == 1) {
		return "$year-$month-$day";
	}

	return "$year-$month-$day " . sprintf("%02d:%02d:%02d UTC", $t[2], $t[1], $t[0]);
}

